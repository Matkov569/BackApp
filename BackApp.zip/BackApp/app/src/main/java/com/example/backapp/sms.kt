package com.example.backapp

class sms(val time:String, var body:String, var sender: String, val sentOrReceived:Boolean) {
    fun getSMS(){
        return
    }
}